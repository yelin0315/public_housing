window.addEventListener('DOMContentLoaded', event => {

    
    const mainNav = document.body.querySelector('#mainNav');
    if (mainNav) {
        new bootstrap.ScrollSpy(document.body, {
            target: '#mainNav',
            offset: 74,
        });
    };

   
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#navbarResponsive .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

});


function toggleSearchModal() {
    var modal = document.getElementById("searchModal");
    modal.classList.toggle("open");
}

function performSearch() {
    var searchInput = document.querySelector("#searchModal input[type='text']").value;
    // 여기서 검색 로직을 수행하세요
}




document.addEventListener('contextmenu', event => event.preventDefault());

[].forEach.call(document.querySelectorAll('path.land'), function(item) {
    item.addEventListener('mouseenter', function() {
        document.getElementById('info-box').innerHTML = this.getAttribute("title");
    });
    item.addEventListener('mouseleave', function() {
        document.getElementById('info-box').innerHTML = ""; // 내용을 지우면 info-box가 사라진다.
    });
});

$(document).mousemove(function(e) {
    $('#info-box').css('top', e.pageY - $('#info-box').height() - 30);
    $('#info-box').css('left', e.pageX - ($('#info-box').width()) / 2);
}).mouseover();


//card
var selectElement = document.getElementById('region-select');
var mapoLink = document.getElementById('link-mapo');
var gangnamLink = document.getElementById('link-gangnam');
var gangseoLink = document.getElementById('link-gangseo');

selectElement.addEventListener('change', function() {
  var selectedValue = selectElement.value;
  
  // 연결 화면 숨기기
  mapoLink.style.display = 'none';
  gangnamLink.style.display = 'none';
  gangseoLink.style.display = 'none';

  // 선택한 값에 따라 연결 화면 표시
  if (selectedValue === '1') {
    mapoLink.style.display = 'block';
  } else if (selectedValue === '2') {
    gangnamLink.style.display = 'block';
  } else if (selectedValue === '3') {
    gangseoLink.style.display = 'block';
  }
});




// chart
var data = {
    labels: ['마포구', '강남구', '서대문구', '영등포구', '강서구'],
    datasets: [{
        label: '지역별 top5',
        data: [85, 59, 40, 21, 10],
        backgroundColor: ['#6ff0c9', 'rgb(135, 235, 227)', 'skyblue', '#0dcaf0', '#cf96eb'],
    }]
};

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: data,
    options: {
        responsive: true, // 반응형 설정
        maintainAspectRatio: false // 캔버스 요소의 종횡비를 유지하지 않음
    }
});


var data = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
    datasets: [{
    label: '월별 경쟁률 추이',
    data: [65, 59, 80, 81, 56, 55, 40],
    fill: false,
    borderColor: 'rgb(75, 192, 192)',
    tension: 0.1
    }]
};
var ctx = document.getElementById('myChart2').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'line', 
    data: data,
    options: {
        responsive: true, // 반응형 설정
        maintainAspectRatio: false // 캔버스 요소의 종횡비를 유지하지 않음
    }
});

